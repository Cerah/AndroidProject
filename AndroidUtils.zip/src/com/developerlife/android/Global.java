package com.developerlife.android;

/**
 * @author Nazmul Idris
 * @version 1.0
 * @since Oct 15, 2010, 6:57:49 PM
 */
public class Global {

public static final String TAG = "TAG1";
public static final String TAG3 = "TAG3";
}//end class Global
